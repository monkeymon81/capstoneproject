<?php
include_once 'db.php';
if(isset($_POST['submit']))
{
  $HolidayId = $_POST['id'];
     $Name = $_POST['name'];
     $price = $_POST['price'];
     $description = $_POST['description'];

$sql = "UPDATE holidayproducts SET Name='$Name', price ='$price', description ='$description' WHERE HolidayId='$HolidayId'";

if ($conn->query($sql) === TRUE) {
  echo "Record updated successfully";
} else {
  echo "Error updating record: " . $conn->error;
}
}
$conn->close();
?>
