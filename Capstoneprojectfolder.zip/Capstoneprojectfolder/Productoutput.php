<html>
<body>
<?php
$username = "root";
$password = "";
$database = "capstone";
$mysqli = new mysqli("localhost", $username, $password, $database);
$query = "SELECT * FROM products ORDER BY ProductId DESC";

echo '<table border="0" cellspacing="2" cellpadding="2">
      <tr>
          <td> <font face="Arial">ID</font> </td>
          <td> <font face="Arial">Name</font> </td>
          <td> <font face="Arial">Price</font> </td>


      </tr>';

if ($result = $mysqli->query($query)) {
    while ($row = $result->fetch_assoc()) {
        $ProductId = $row["ProductId"];
        $Name = $row["Name"];
        $price = $row["price"];



        echo '<tr>
                  <td>'.$ProductId.'</td>
                  <td>'.$Name.'</td>
                  <td>'.$price.'</td>


              </tr>';
    }
    $result->free();
}
?>
</body>
</html>
}
