<html>
<body>
<?php
$username = "root";
$password = "";
$database = "capstone";
$mysqli = new mysqli("localhost", $username, $password, $database);
$query = "SELECT * FROM holidayproducts";

echo '<table border="0" cellspacing="2" cellpadding="2">
      <tr>
          <td> <font face="Arial">ID</font> </td>
          <td> <font face="Arial">Name</font> </td>
          <td> <font face="Arial">Price</font> </td>
          <td> <font face="Arial">Description</font> </td>

      </tr>';

if ($result = $mysqli->query($query)) {
    while ($row = $result->fetch_assoc()) {
        $HolidayId = $row["HolidayId"];
        $NAME = $row["NAME"];
        $Price = $row["Price"];
        $description = $row["description"];


        echo '<tr>
                  <td>'.$HolidayId.'</td>
                  <td>'.$NAME.'</td>
                  <td>'.$Price.'</td>
                  <td>'.$description.'</td>

              </tr>';
    }
    $result->free();
}
?>
</body>
</html>
}
