<?php
include_once 'db.php';
if(isset($_POST['submit']))
{
     $Name = $_POST['name'];
     $price = $_POST['price'];


     $sql = "INSERT INTO products (Name,price)
     VALUES ('$Name','$price')";

     if (mysqli_query($conn, $sql)) {
        echo "New record has been added successfully !";
     } else {
        echo "Error: " . $sql . ":-" . mysqli_error($conn);
     }
     mysqli_close($conn);
}
?>
