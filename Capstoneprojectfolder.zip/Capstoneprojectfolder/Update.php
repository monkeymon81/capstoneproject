<?php
include_once 'db.php';
if(isset($_POST['submit']))
{
  $ProductId = $_POST['id'];
     $Name = $_POST['name'];
     $price = $_POST['price'];

$sql = "UPDATE products SET Name='$Name', price ='$price' WHERE ProductId='$ProductId'";

if ($conn->query($sql) === TRUE) {
  echo "Record updated successfully";
} else {
  echo "Error updating record: " . $conn->error;
}
}
$conn->close();
?>
