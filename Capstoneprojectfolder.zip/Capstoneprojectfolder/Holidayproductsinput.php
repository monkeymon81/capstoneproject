<?php
include_once 'db.php';
if(isset($_POST['submit']))
{
     $Name = $_POST['name'];
     $price = $_POST['price'];
     $description = $_POST ['description'];


     $sql = "INSERT INTO holidayproducts (Name,price,description)
     VALUES ('$Name','$price','$description')";

     if (mysqli_query($conn, $sql)) {
        echo "New record has been added successfully !";
     } else {
        echo "Error: " . $sql . ":-" . mysqli_error($conn);
     }
     mysqli_close($conn);
}
?>
