<?php
include_once 'db.php';
if(isset($_POST['submit']))
{
  $ProductId = $_POST['id'];


  $sql = "DELETE FROM products WHERE ProductId='$ProductId'";

  if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully";
  } else {
    echo "Error deleting record: " . $conn->error;
  }
}
?>
